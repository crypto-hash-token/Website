
export const nftmarketplaceaddress = "0xcC00257dC6dA945b7daDE3cbb5268C94ebe59B6b"
export const nftaddress = "0x9f2f10Ea80Fd6c0B892d3eb9Ae6B621521af7960"
export const mintpassaddress = "0xBCFd95Dc648Faa4d34f8B6c5038C03b7E2609536"
