module.exports = {
  reactStrictMode: true,
  ignoreDuringBuilds: true,
}
